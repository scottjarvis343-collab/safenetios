import Foundation

enum SafeNetConfig {
    // TODO: Use your real backend URLs
    static let apiBaseURL = URL(string: "https://api.safenettechnology.com")!
    static let blockPageBaseURL = URL(string: "https://block.safenettechnology.com/blocked")!

    // AGH DNS servers (replace with your actual SafeNet/AGH IP)
    static let aghDnsIPv4 = "3.129.187.175"        // change to your AGH DNS IP
    static let aghDnsIPv6: String? = nil           // set if you expose IPv6 DNS

    // Fake marker IPs returned by AGH for blocked domains
    static let blockedIPv4Marker = "192.0.2.123"
    static let blockedIPv6Marker = "2001:db8::123"

    // App Group for sharing data between app and VPN extension
    static let appGroupIdentifier = "group.com.safenettechnology.safenetapp"

    // Shared keys (existing)
    static let sharedCIDKey = "safenet.cid"
    static let sharedDeviceIdKey = "safenet.deviceId"
    static let sharedChildNameKey = "safenet.childName"
    static let sharedUserTagKey   = "safenet.userTag"
    static let sharedUniqueIdKey  = "safenet.shared.uniqueId"
    static let sharedPushTokenKey = "safenet_push_token"

    // NEW: DNS (DoH) approach keys
    static let sharedDoHURLKey = "safenet.dohUrl"           // e.g. https://dns.safenettechnology.com/dns-query/<cid>
    static let sharedDnsProfileNameKey = "safenet.dnsProfileName"

    // NEW: Default DoH base (backend may return a per-user URL; this is fallback)
    // We'll build final URL as: "\(defaultDoHBase)/\(cid)"
    static let defaultDoHBase = "https://dns.safenettechnology.com/dns-query"
    static let dnsProfileDisplayName = "SafeNet DNS"
}

enum SharedDefaults {
    static var instance: UserDefaults {
        if let ud = UserDefaults(suiteName: SafeNetConfig.appGroupIdentifier) {
            return ud
        }
        return .standard
    }
}
