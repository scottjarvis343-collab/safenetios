import UIKit
import UserNotifications
import Foundation

// MARK: - Push Token Manager (APNs -> Backend /public/push/register)

final class PushTokenManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = PushTokenManager()

    // Store token in SharedDefaults (same place you store pairing)
    private let ud = SharedDefaults.instance

    // Keys
    private let kApnsTokenHex = "safenet_apns_token_hex"
    private let kLastUploadedUserTag = "safenet_apns_last_uploaded_usertag"
    private let kLastUploadedTokenHex = "safenet_apns_last_uploaded_token_hex"

    private override init() {
        super.init()
    }

    /// Call once during app boot
    func configure() {
        UNUserNotificationCenter.current().delegate = self
    }

    /// Ask permission + register for APNs
    func requestPermissionAndRegister() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, err in
            if let err = err {
                print("SafeNet[APNS] permission error:", err.localizedDescription)
                return
            }
            print("SafeNet[APNS] permission granted:", granted)
            guard granted else { return }
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }

    /// Called by AppDelegate when APNs token arrives
    func didRegisterForRemoteNotifications(deviceToken: Data) {
        let tokenHex = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        print("SafeNet[APNS] tokenHex len=\(tokenHex.count) head=\(tokenHex.prefix(8))")

        ud.set(tokenHex, forKey: kApnsTokenHex)
        ud.synchronize()

        // Try upload immediately (will only succeed if userTag exists)
        tryUploadNow()
    }

    func didFailToRegister(error: Error) {
        print("SafeNet[APNS] registration failed:", error.localizedDescription)
    }

    /// Call this after pairing is saved (when userTag becomes available)
    func tryUploadNow() {
        let tokenHex = (ud.string(forKey: kApnsTokenHex) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let userTag = (ud.string(forKey: SafeNetConfig.sharedUserTagKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        if tokenHex.isEmpty {
            print("SafeNet[APNS] tryUploadNow: no token yet")
            return
        }
        if userTag.isEmpty {
            print("SafeNet[APNS] tryUploadNow: no userTag yet (pairing not done)")
            return
        }

        // Avoid spamming the API: upload only if userTag or token changed
        let lastTag = ud.string(forKey: kLastUploadedUserTag) ?? ""
        let lastTok = ud.string(forKey: kLastUploadedTokenHex) ?? ""
        if lastTag == userTag && lastTok == tokenHex {
            print("SafeNet[APNS] tryUploadNow: already uploaded for this userTag+token")
            return
        }

        // Optional deviceId
        let deviceIdStr = (ud.string(forKey: SafeNetConfig.sharedDeviceIdKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let deviceIdInt: Int? = Int(deviceIdStr)

        uploadPushToken(userTag: userTag, tokenHex: tokenHex, deviceId: deviceIdInt) { ok in
            if ok {
                self.ud.set(userTag, forKey: self.kLastUploadedUserTag)
                self.ud.set(tokenHex, forKey: self.kLastUploadedTokenHex)
                self.ud.synchronize()
                print("SafeNet[APNS] register ok (userTag=\(userTag))")
            } else {
                print("SafeNet[APNS] register failed (userTag=\(userTag))")
            }
        }
    }

    private func uploadPushToken(userTag: String, tokenHex: String, deviceId: Int?, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "https://api.safenettechnology.com/public/push/register") else {
            completion(false)
            return
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        var body: [String: Any] = [
            "user_tag": userTag,
            "token": tokenHex
        ]
        if let deviceId = deviceId {
            body["deviceId"] = deviceId
        }

        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("SafeNet[APNS] register network error:", err.localizedDescription)
                completion(false)
                return
            }

            let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let raw = String(data: data ?? Data(), encoding: .utf8) ?? ""
            print("SafeNet[APNS] register status=\(status) body=\(raw)")

            completion((200...299).contains(status))
        }.resume()
    }

    // Show notifications as banners when app is open
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}

// MARK: - AppDelegate

final class AppDelegate: NSObject, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {

        PushTokenManager.shared.configure()
        PushTokenManager.shared.requestPermissionAndRegister()

        return true
    }

    func application(
        _ application: UIApplication,
        didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data
    ) {
        PushTokenManager.shared.didRegisterForRemoteNotifications(deviceToken: deviceToken)
    }

    func application(
        _ application: UIApplication,
        didFailToRegisterForRemoteNotificationsWithError error: Error
    ) {
        PushTokenManager.shared.didFailToRegister(error: error)
    }
}
