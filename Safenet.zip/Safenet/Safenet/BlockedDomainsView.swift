import SwiftUI

struct BlockedDomain: Identifiable, Decodable {
    let id = UUID()
    let domain: String
    let count: Int
    let lastSeen: String
}

struct BlockedDomainsView: View {
    @State private var items: [BlockedDomain] = []

    var body: some View {
        List(items) { item in
            VStack(alignment: .leading) {
                Text(item.domain).font(.headline)
                Text("Blocked \(item.count)x today")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Blocked Today")
        .onAppear(perform: load)
    }

    private func load() {
        guard
            let deviceId = SharedDefaults.instance.string(forKey: SafeNetConfig.sharedDeviceIdKey)
        else { return }

        let url = SafeNetConfig.apiBaseURL
            .appendingPathComponent("devices/\(deviceId)/blocked?hours=24")

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data else { return }
            if let decoded = try? JSONDecoder().decode([BlockedDomain].self, from: data) {
                DispatchQueue.main.async { self.items = decoded }
            }
        }.resume()
    }
}
