import Foundation
import UIKit
import UserNotifications
import Combine

final class PushManager: NSObject, ObservableObject, UNUserNotificationCenterDelegate {

    static let shared = PushManager()

    @Published var lastToken: String? = nil

    private override init() {
        super.init()
        // delegate is also set in AppDelegate, but keeping here is fine
        UNUserNotificationCenter.current().delegate = self
    }

    func requestPermissionAndRegister() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, err in
            if let err = err {
                print("SafeNet[APNs] permission error:", err.localizedDescription)
                return
            }
            print("SafeNet[APNs] permission granted:", granted)

            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }

    func didRegisterForRemoteNotifications(deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02x", $0) }.joined()
        print("SafeNet[APNs] device token:", token)

        DispatchQueue.main.async { self.lastToken = token }

        // store locally
        SharedDefaults.instance.set(token, forKey: SafeNetConfig.sharedPushTokenKey)
        SharedDefaults.instance.synchronize()

        // send to backend
        uploadTokenToBackend(token: token)
    }

    func didFailToRegister(error: Error) {
        print("SafeNet[APNs] register failed:", error.localizedDescription)
    }

    // Show banner when notification arrives in foreground
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }

    // Tap handling (we can deep link later)
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        print("SafeNet[APNs] tapped userInfo:", userInfo)
        completionHandler()
    }

    private func uploadTokenToBackend(token: String) {
        let ud = SharedDefaults.instance
        let userTag = ud.string(forKey: SafeNetConfig.sharedUserTagKey)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let deviceId = ud.string(forKey: SafeNetConfig.sharedDeviceIdKey)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let cid = ud.string(forKey: SafeNetConfig.sharedCIDKey)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        guard !userTag.isEmpty else {
            print("SafeNet[APNs] skip upload (missing userTag)")
            return
        }

        var req = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("push/register"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "user_tag": userTag,
            "deviceId": deviceId,
            "cid": cid,
            "platform": "ios",
            "token": token
        ]

        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            print("SafeNet[APNs] upload body encode failed:", error.localizedDescription)
            return
        }

        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("SafeNet[APNs] upload failed:", err.localizedDescription)
                return
            }
            let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let raw = String(data: data ?? Data(), encoding: .utf8) ?? ""
            print("SafeNet[APNs] upload status:", status, raw.prefix(200))
        }.resume()
    }
}
