import Foundation

final class PushRegisterService {
    static let shared = PushRegisterService()
    private init() {}

    func register(token: String) {
        let userTag = SharedDefaults.instance.string(forKey: SafeNetConfig.sharedUserTagKey) ?? ""
        if userTag.isEmpty {
            print("PushRegister: missing userTag, skipping")
            return
        }

        guard let url = URL(string: "https://api.safenettechnology.com/public/push/register") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "user_tag": userTag,   // IMPORTANT: snake_case to match backend
            "token": token
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("PushRegister failed:", err.localizedDescription)
                return
            }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            print("PushRegister status:", code, "body:", text)
        }.resume()
    }
}
