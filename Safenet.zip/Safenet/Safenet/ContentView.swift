import SwiftUI
import NetworkExtension
import UIKit

struct ContentView: View {
    // MARK: - Pairing info
    @State private var cid: String? = nil
    @State private var deviceId: String? = nil
    @State private var childName: String? = nil
    @State private var userTag: String? = nil

    // DoH URL (optional, can be returned by backend)
    @State private var dohURL: String? = nil

    // MARK: - UI state
    @State private var pairingCode: String = ""
    @State private var isPairing: Bool = false
    @State private var pairingError: String? = nil

    // MARK: - DNS state
    @State private var dnsEnabled: Bool = false
    @State private var isDnsBusy: Bool = false
    @State private var dnsError: String? = nil
    @State private var dnsStatusText: String = "DNS Status: Unknown"

    // MARK: - Best-UX states
    @State private var showEnableDnsSheet: Bool = false
    @State private var pendingEnableAfterSave: Bool = false
    @State private var hasSavedDnsConfig: Bool = false

    var body: some View {
        NavigationView {
            Group {
                if isPaired {
                    pairedView
                } else {
                    pairingView
                }
            }
            .navigationTitle("SafeNet")
        }
        .onAppear {
            loadStoredPairing()
            refreshDnsStatus {
                sendHeartbeat()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            refreshDnsStatus {
                // Close sheet automatically once enabled
                if pendingEnableAfterSave, dnsEnabled {
                    showEnableDnsSheet = false
                    pendingEnableAfterSave = false
                }
                sendHeartbeat()
            }
        }
        .sheet(isPresented: $showEnableDnsSheet) {
            EnableDnsSheet(
                dnsProfileName: SafeNetConfig.dnsProfileDisplayName,
                dohURL: dohURL ?? "",
                isEnabled: dnsEnabled,
                statusText: dnsStatusText,
                onOpenSettings: { openAppSettings() },
                onRecheck: {
                    refreshDnsStatus {
                        sendHeartbeat()
                    }
                }
            )
        }
    }

    // MARK: - Computed

    // ✅ FIX: include userTag too (Blocked Today requires it)
    private var isPaired: Bool {
        let hasCid = (cid?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
        let hasDeviceId = (deviceId?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
        let hasUserTag = (userTag?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
        return hasCid && hasDeviceId && hasUserTag
    }

    // MARK: - Views

    private var pairingView: some View {
        VStack(spacing: 20) {
            Text("Pair this device with SafeNet")
                .font(.title3)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)

            Text("Enter the pairing code or scan the QR shown in the parent dashboard.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)

            TextField("Pairing code", text: $pairingCode)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.none)
                .disableAutocorrection(true)

            HStack(spacing: 16) {
                Button {
                    // TODO: implement QR scan later
                    print("SafeNet[PAIR] QR scan tapped (not yet implemented)")
                } label: {
                    HStack {
                        Image(systemName: "qrcode.viewfinder")
                        Text("Scan QR")
                    }
                }
                .buttonStyle(.bordered)

                Button {
                    pairDevice()
                } label: {
                    if isPairing {
                        ProgressView().progressViewStyle(.circular)
                    } else {
                        Text("Pair Device")
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isPairing || pairingCode.trimmingCharacters(in: .whitespaces).isEmpty)
            }

            if let pairingError {
                Text(pairingError)
                    .font(.footnote)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }

            Spacer()
        }
        .padding()
    }

    private var pairedView: some View {
        VStack(spacing: 18) {

            // Banner: DNS config saved but not enabled
            if isDnsConfigSavedButNotEnabled {
                EnableProtectionBanner(
                    dnsProfileName: SafeNetConfig.dnsProfileDisplayName,
                    onTap: {
                        pendingEnableAfterSave = true
                        showEnableDnsSheet = true
                    },
                    onOpenSettings: { openAppSettings() }
                )
            }

            if let name = childName {
                HStack {
                    Text("Paired with:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(name)
                        .font(.headline)
                        .fontWeight(.semibold)
                    Spacer()
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(dnsStatusText)
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                if let dohURL = dohURL, !dohURL.isEmpty {
                    Text("DoH: \(dohURL)")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            Button(action: toggleDnsProtection) {
                ZStack {
                    Circle()
                        .fill(dnsEnabled ? Color.green.opacity(0.9) : Color.blue.opacity(0.9))
                        .frame(width: 140, height: 140)

                    VStack(spacing: 8) {
                        if isDnsBusy {
                            ProgressView()
                                .progressViewStyle(.circular)
                                .tint(.white)
                        } else {
                            Image(systemName: dnsEnabled ? "shield.checkerboard" : "shield.slash")
                                .font(.system(size: 32, weight: .medium))
                                .foregroundColor(.white)
                        }

                        Text(dnsEnabled ? "Protection ON" : "Enable Protection")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                }
            }
            .disabled(isDnsBusy)

            if let dnsError {
                Text(dnsError)
                    .font(.footnote)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }

            // Quick actions
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Button {
                        openAppSettings()
                    } label: {
                        HStack {
                            Image(systemName: "gearshape.fill")
                            Text("Open Settings")
                        }
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        pendingEnableAfterSave = true
                        showEnableDnsSheet = true
                    } label: {
                        HStack {
                            Image(systemName: "checklist")
                            Text("Show Steps")
                        }
                    }
                    .buttonStyle(.bordered)
                }

                NavigationLink {
                    BlockedDomainsListView()
                } label: {
                    HStack {
                        Image(systemName: "hand.raised.fill")
                        Text("Blocked Today")
                    }
                }
                .buttonStyle(.bordered)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 6)

            Spacer()

            Button(role: .destructive) {
                unpairDevice()
            } label: {
                Text("Unpair this device")
            }
            .padding(.bottom, 8)
        }
        .padding()
    }

    // MARK: - Best-UX Computed

    private var isDnsConfigSavedButNotEnabled: Bool {
        return hasSavedDnsConfig && !dnsEnabled
    }

    // MARK: - Pairing

    private func loadStoredPairing() {
        let ud = SharedDefaults.instance
        let storedCid      = ud.string(forKey: SafeNetConfig.sharedCIDKey)
        let storedDeviceId = ud.string(forKey: SafeNetConfig.sharedDeviceIdKey)
        let storedChild    = ud.string(forKey: SafeNetConfig.sharedChildNameKey)
        let storedUserTag  = ud.string(forKey: SafeNetConfig.sharedUserTagKey)
        let storedDoH      = ud.string(forKey: SafeNetConfig.sharedDoHURLKey)

        cid = storedCid
        deviceId = storedDeviceId
        childName = storedChild
        userTag = storedUserTag
        dohURL = storedDoH

        print("SafeNet[STORE] loadStoredPairing()")
        print("  cid      = \(storedCid ?? "nil")")
        print("  deviceId = \(storedDeviceId ?? "nil")")
        print("  child    = \(storedChild ?? "nil")")
        print("  userTag  = \(storedUserTag ?? "nil")")
        print("  dohURL   = \(storedDoH ?? "nil")")
    }

    private func storePairing(cid: String, deviceId: String, childName: String, userTag: String, dohURL: String?) {
        let ud = SharedDefaults.instance
        ud.set(cid,       forKey: SafeNetConfig.sharedCIDKey)
        ud.set(deviceId,  forKey: SafeNetConfig.sharedDeviceIdKey)
        ud.set(childName, forKey: SafeNetConfig.sharedChildNameKey)
        ud.set(userTag,   forKey: SafeNetConfig.sharedUserTagKey)

        if let dohURL, !dohURL.isEmpty {
            ud.set(dohURL, forKey: SafeNetConfig.sharedDoHURLKey)
        } else {
            ud.removeObject(forKey: SafeNetConfig.sharedDoHURLKey)
        }

        ud.synchronize()
        print("saved userTag:", SharedDefaults.instance.string(forKey: SafeNetConfig.sharedUserTagKey) ?? "nil")
        print("saved deviceId:", SharedDefaults.instance.string(forKey: SafeNetConfig.sharedDeviceIdKey) ?? "nil")
        self.cid = cid
        self.deviceId = deviceId
        self.childName = childName
        self.userTag = userTag
        self.dohURL = dohURL

        print("SafeNet[STORE] storePairing()")
        print("  cid      = \(cid)")
        print("  deviceId = \(deviceId)")
        print("  child    = \(childName)")
        print("  userTag  = \(userTag)")
        print("  dohURL   = \(dohURL ?? "nil")")
        PushTokenManager.shared.tryUploadNow()
    }

    private func unpairDevice() {
        print("SafeNet[PAIR] unpairDevice() – clearing stored values & disabling DNS")

        let ud = SharedDefaults.instance
        ud.removeObject(forKey: SafeNetConfig.sharedCIDKey)
        ud.removeObject(forKey: SafeNetConfig.sharedDeviceIdKey)
        ud.removeObject(forKey: SafeNetConfig.sharedChildNameKey)
        ud.removeObject(forKey: SafeNetConfig.sharedUserTagKey)
        ud.removeObject(forKey: SafeNetConfig.sharedDoHURLKey)
        ud.synchronize()

        cid = nil
        deviceId = nil
        childName = nil
        userTag = nil
        dohURL = nil

        pairingError = nil
        dnsError = nil

        disableDnsProtection()
    }

    private func pairDevice() {
        pairingError = nil
        dnsError = nil

        let trimmedCode = pairingCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedCode.isEmpty else { return }

        isPairing = true

        let ud = SharedDefaults.instance
        let existingUniqueId = ud.string(forKey: SafeNetConfig.sharedUniqueIdKey)
        let uniqueId: String
        if let existing = existingUniqueId {
            uniqueId = existing
        } else {
            let newId = UUID().uuidString
            ud.set(newId, forKey: SafeNetConfig.sharedUniqueIdKey)
            ud.synchronize()
            uniqueId = newId
            print("SafeNet[PAIR] Generated new uniqueId: \(uniqueId)")
        }

        let deviceName = UIDevice.current.name
        let deviceModel = UIDevice.current.model
        let platform = "ios"

        var request = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("devices/pair"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        struct PairingRequestBody: Codable {
            let code: String
            let uniqueId: String
            let deviceName: String
            let deviceModel: String
            let platform: String
        }

        let body = PairingRequestBody(
            code: trimmedCode,
            uniqueId: uniqueId,
            deviceName: deviceName,
            deviceModel: deviceModel,
            platform: platform
        )

        do {
            request.httpBody = try JSONEncoder().encode(body)
        } catch {
            DispatchQueue.main.async {
                self.pairingError = "Failed to build pairing request."
                self.isPairing = false
            }
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async { self.isPairing = false }

            if let error = error {
                DispatchQueue.main.async { self.pairingError = "Network error: \(error.localizedDescription)" }
                return
            }

            guard let http = response as? HTTPURLResponse else {
                DispatchQueue.main.async { self.pairingError = "Invalid server response." }
                return
            }

            guard (200...299).contains(http.statusCode), let data = data else {
                let msg = HTTPURLResponse.localizedString(forStatusCode: http.statusCode)
                DispatchQueue.main.async { self.pairingError = "Pairing failed (\(http.statusCode)): \(msg)" }
                return
            }

            do {
                let decoded = try JSONDecoder().decode(PairingResponse.self, from: data)

                let effectiveCid      = decoded.cidEffective
                let effectiveDeviceId = decoded.deviceIdEffective
                let effectiveChild    = decoded.childNameEffective
                let effectiveUserTag  = decoded.userTagEffective

                let backendDoH = decoded.dns?.dohWithId ?? decoded.dns?.doh
                let effectiveDoH: String? = {
                    if let backendDoH, !backendDoH.isEmpty { return backendDoH }
                    if !effectiveCid.isEmpty { return "\(SafeNetConfig.defaultDoHBase)/\(effectiveCid)" }
                    return nil
                }()

                DispatchQueue.main.async {
                    self.storePairing(
                        cid: effectiveCid,
                        deviceId: effectiveDeviceId,
                        childName: effectiveChild,
                        userTag: effectiveUserTag,
                        dohURL: effectiveDoH
                    )
                    self.pairingCode = ""
                    self.enableDnsProtection(openEnableSheetOnSuccess: true)
                }
            } catch {
                DispatchQueue.main.async { self.pairingError = "Failed to decode pairing response." }
            }
        }

        task.resume()
    }

    // MARK: - DNS Settings (NEDNSSettingsManager)

    private func refreshDnsStatus(completion: (() -> Void)? = nil) {
        let manager = NEDNSSettingsManager.shared()
        manager.loadFromPreferences { error in
            DispatchQueue.main.async {
                if let error = error {
                    self.dnsEnabled = false
                    self.hasSavedDnsConfig = false
                    self.dnsStatusText = "DNS Status: Error"
                    self.dnsError = "Failed to load DNS preferences: \(error.localizedDescription)"
                    completion?()
                    return
                }

                self.dnsEnabled = manager.isEnabled
                self.hasSavedDnsConfig = (manager.dnsSettings != nil)

                if manager.isEnabled {
                    self.dnsStatusText = "DNS Status: Enabled"
                } else if manager.dnsSettings != nil {
                    self.dnsStatusText = "DNS Status: Saved (enable in Settings)"
                } else {
                    self.dnsStatusText = "DNS Status: Disabled"
                }

                completion?()
            }
        }
    }

    private func toggleDnsProtection() {
        if dnsEnabled {
            disableDnsProtection()
        } else {
            enableDnsProtection(openEnableSheetOnSuccess: true)
        }
    }

    private func enableDnsProtection(openEnableSheetOnSuccess: Bool) {
        guard isPaired, let cid = self.cid, !cid.isEmpty else {
            dnsError = "Device is not paired."
            return
        }

        dnsError = nil
        isDnsBusy = true

        let manager = NEDNSSettingsManager.shared()

        manager.loadFromPreferences { error in
            if let error = error {
                DispatchQueue.main.async {
                    self.dnsError = "Error loading DNS prefs: \(error.localizedDescription)"
                    self.isDnsBusy = false
                }
                return
            }

            let dohString: String = {
                if let s = self.dohURL, !s.isEmpty { return s }
                return "\(SafeNetConfig.defaultDoHBase)/\(cid)"
            }()

            guard let dohURL = URL(string: dohString) else {
                DispatchQueue.main.async {
                    self.dnsError = "Invalid DoH URL."
                    self.isDnsBusy = false
                }
                return
            }

            let dohSettings = NEDNSOverHTTPSSettings(servers: [SafeNetConfig.aghDnsIPv4])
            dohSettings.serverURL = dohURL
            dohSettings.matchDomains = [""] // global

            manager.localizedDescription = SafeNetConfig.dnsProfileDisplayName
            manager.dnsSettings = dohSettings

            manager.saveToPreferences { error in
                DispatchQueue.main.async {
                    self.isDnsBusy = false
                    if let error = error {
                        self.dnsError = "Error saving DNS prefs: \(error.localizedDescription)"
                        self.refreshDnsStatus()
                        return
                    }

                    // Save DoH URL locally as well
                    let ud = SharedDefaults.instance
                    ud.set(dohString, forKey: SafeNetConfig.sharedDoHURLKey)
                    ud.synchronize()
                    self.dohURL = dohString

                    self.dnsError = nil
                    self.refreshDnsStatus {
                        self.sendHeartbeat()
                    }

                    // Best UX: present steps immediately after save
                    if openEnableSheetOnSuccess {
                        self.pendingEnableAfterSave = true
                        self.showEnableDnsSheet = true
                    }

                    print("SafeNet[DNS] Saved DoH DNS settings: \(dohString)")
                }
            }
        }
    }

    private func disableDnsProtection() {
        dnsError = nil
        isDnsBusy = true

        let manager = NEDNSSettingsManager.shared()
        manager.loadFromPreferences { error in
            if let error = error {
                DispatchQueue.main.async {
                    self.dnsError = "Error loading DNS prefs: \(error.localizedDescription)"
                    self.isDnsBusy = false
                }
                return
            }

            manager.dnsSettings = nil

            manager.saveToPreferences { error in
                DispatchQueue.main.async {
                    self.isDnsBusy = false
                    if let error = error {
                        self.dnsError = "Error disabling DNS: \(error.localizedDescription)"
                        self.refreshDnsStatus()
                        return
                    }
                    self.dnsError = nil
                    self.pendingEnableAfterSave = false
                    self.showEnableDnsSheet = false
                    self.refreshDnsStatus {
                        self.sendHeartbeat()
                    }
                    print("SafeNet[DNS] Removed DNS settings (disabled)")
                }
            }
        }
    }

    // MARK: - Heartbeat (foreground-based)

    private func sendHeartbeat() {
        guard let deviceId = self.deviceId, let cid = self.cid else { return }

        let payload: [String: Any] = [
            "deviceId": deviceId,
            "cid": cid,
            "dnsEnabled": dnsEnabled,
            "hasSavedDnsConfig": hasSavedDnsConfig,
            "dohUrl": dohURL ?? "",
            "ts": Int(Date().timeIntervalSince1970)
        ]

        var req = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("devices/heartbeat"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        URLSession.shared.dataTask(with: req) { _, _, _ in }.resume()
    }

    // MARK: - Settings (App Store safe)

    private func openAppSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}



// MARK: - Blocked Today View (server-driven) — Dedup + Main-domain only + Request Access

private struct BlockedDomainsListView: View {

    // API: /public/blocked-today response
    struct BlockedTodayResponse: Decodable {
        let ok: Bool
        let cid: String
        let startOfDay: String
        let items: [BlockedDomain]
    }

    // Raw item from API
    // Supports BOTH:
    // - /public/blocked-today => lastSeenAt
    // - /devices/:id/blocked  => lastSeen
    struct BlockedDomain: Decodable {
        let domain: String
        let count: Int
        let blockedAt: String?
        let lastSeenAt: String

        enum CodingKeys: String, CodingKey {
            case domain
            case count
            case blockedAt
            case lastSeenAt
            case lastSeen
        }

        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            domain = (try? c.decode(String.self, forKey: .domain)) ?? ""
            count = (try? c.decode(Int.self, forKey: .count)) ?? 0
            blockedAt = try? c.decodeIfPresent(String.self, forKey: .blockedAt)

            // prefer lastSeenAt, fallback to lastSeen
            if let v = try? c.decode(String.self, forKey: .lastSeenAt) {
                lastSeenAt = v
            } else if let v = try? c.decode(String.self, forKey: .lastSeen) {
                lastSeenAt = v
            } else {
                lastSeenAt = ""
            }
        }
    }

    // Aggregated row shown in UI
    struct DomainRow: Identifiable {
        let id: String              // main domain
        let domain: String          // main domain
        let totalCount: Int
        let lastSeenISO: String
        let lastSeenDate: Date
    }

    // Request access API
    struct AccessRequestBody: Encodable {
        let domain: String
        let user_tag: String
    }

    struct AccessRequestResp: Decodable {
        let ok: Bool?
        let ids: [String]?
        let count: Int?
        let error: String?
    }

    @State private var rows: [DomainRow] = []
    @State private var isLoading: Bool = false
    @State private var errorText: String? = nil
    @State private var debugText: String? = nil

    // per-row request state
    @State private var requesting: Set<String> = []
    @State private var requestedOk: Set<String> = []
    @State private var requestErrorByDomain: [String: String] = [:]

    var body: some View {
        VStack(spacing: 0) {

            if isLoading {
                VStack(spacing: 12) {
                    ProgressView()
                    Text("Loading blocked domains…")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                .padding(.top, 24)
            }

            if let errorText {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Error")
                        .font(.headline)
                        .foregroundColor(.red)

                    Text(errorText)
                        .font(.footnote)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.leading)

                    if let debugText, !debugText.isEmpty {
                        Text("Debug")
                            .font(.headline)
                            .padding(.top, 8)

                        ScrollView {
                            Text(debugText)
                                .font(.system(.footnote, design: .monospaced))
                                .foregroundColor(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.top, 4)
                        }
                        .frame(maxHeight: 220)
                    }
                }
                .padding()
            }

            if !isLoading && errorText == nil && rows.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "hand.raised.slash.fill")
                        .font(.system(size: 30))
                        .foregroundColor(.secondary)

                    Text("No blocked sites today")
                        .font(.headline)

                    Text("If you expected entries, open a blocked site once and refresh.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                }
                .padding(.top, 28)
            }

            if !rows.isEmpty {
                List(rows) { item in
                    VStack(alignment: .leading, spacing: 8) {

                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.domain)
                                    .font(.headline)

                                Text("Blocked \(item.totalCount)x • Last: \(item.lastSeenISO)")
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                            }

                            Spacer()

                            Button {
                                requestAccess(for: item.domain)
                            } label: {
                                HStack(spacing: 8) {
                                    if requesting.contains(item.domain) {
                                        ProgressView().progressViewStyle(.circular)
                                    } else if requestedOk.contains(item.domain) {
                                        Image(systemName: "checkmark.circle.fill")
                                    } else {
                                        Image(systemName: "paperplane.fill")
                                    }

                                    Text(requestedOk.contains(item.domain) ? "Requested" : "Request")
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(requesting.contains(item.domain) || requestedOk.contains(item.domain))
                        }

                        if let msg = requestErrorByDomain[item.domain], !msg.isEmpty {
                            Text(msg)
                                .font(.footnote)
                                .foregroundColor(.red)
                        } else if requestedOk.contains(item.domain) {
                            Text("Request sent to parent/admin.")
                                .font(.footnote)
                                .foregroundColor(.green)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Blocked Today")
        .toolbar { Button("Refresh") { load() } }
        .task { load() }
    }

    // MARK: - Load blocked list

    private func load() {
        errorText = nil
        debugText = nil
        isLoading = true
        requestErrorByDomain = [:]

        // ✅ use correct key
        let ud = SharedDefaults.instance
        let storedUserTag = ud.string(forKey: SafeNetConfig.sharedUserTagKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let storedCid = ud.string(forKey: SafeNetConfig.sharedCIDKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let identifierToQuery: String? = {
            if let t = storedUserTag, !t.isEmpty { return t }
            if let c = storedCid, !c.isEmpty { return c }
            return nil
        }()

        guard let identifierToQuery else {
            isLoading = false
            errorText = "Device not paired (missing user tag / cid)."
            return
        }

        var comps = URLComponents(
            url: SafeNetConfig.apiBaseURL.appendingPathComponent("public/blocked-today"),
            resolvingAgainstBaseURL: false
        )
        comps?.queryItems = [
            URLQueryItem(name: "cid", value: identifierToQuery),
            URLQueryItem(name: "limit", value: "200"),
            URLQueryItem(name: "tz", value: "330")
        ]

        guard let url = comps?.url else {
            isLoading = false
            errorText = "Invalid blocked list URL."
            return
        }

        URLSession.shared.dataTask(with: url) { data, resp, err in
            DispatchQueue.main.async { self.isLoading = false }

            if let err = err {
                DispatchQueue.main.async { self.errorText = "Network error: \(err.localizedDescription)" }
                return
            }

            let http = resp as? HTTPURLResponse
            let status = http?.statusCode ?? 0
            let raw = String(data: data ?? Data(), encoding: .utf8) ?? ""

            guard let data = data else {
                DispatchQueue.main.async { self.errorText = "No response from server." }
                return
            }

            do {
                let decoded = try JSONDecoder().decode(BlockedTodayResponse.self, from: data)
                let aggregated = aggregateToMainDomains(decoded.items)

                DispatchQueue.main.async {
                    self.rows = aggregated.sorted(by: { $0.lastSeenDate > $1.lastSeenDate })
                }
            } catch {
                DispatchQueue.main.async {
                    self.rows = []
                    self.errorText = "Failed to parse blocked list (HTTP \(status))."
                    self.debugText = raw.isEmpty ? "\(error)" : raw
                }
            }
        }.resume()
    }

    // MARK: - Request Access

    private func requestAccess(for domain: String) {
        let tag = SharedDefaults.instance.string(forKey: SafeNetConfig.sharedUserTagKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        guard !tag.isEmpty else {
            requestErrorByDomain[domain] = "Device not paired (missing user tag)."
            return
        }

        requesting.insert(domain)
        requestErrorByDomain[domain] = nil

        var req = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("requests/open"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = AccessRequestBody(domain: domain, user_tag: tag)
        do {
            req.httpBody = try JSONEncoder().encode(body)
        } catch {
            requesting.remove(domain)
            requestErrorByDomain[domain] = "Failed to build request."
            return
        }

        URLSession.shared.dataTask(with: req) { data, resp, err in
            DispatchQueue.main.async { self.requesting.remove(domain) }

            if let err = err {
                DispatchQueue.main.async { self.requestErrorByDomain[domain] = "Network error: \(err.localizedDescription)" }
                return
            }

            let http = resp as? HTTPURLResponse
            let status = http?.statusCode ?? 0
            let raw = String(data: data ?? Data(), encoding: .utf8) ?? ""

            guard (200...299).contains(status), let data = data else {
                DispatchQueue.main.async {
                    self.requestErrorByDomain[domain] = raw.isEmpty
                        ? "Request failed (HTTP \(status))."
                        : "Request failed (HTTP \(status)): \(raw)"
                }
                return
            }

            if let decoded = try? JSONDecoder().decode(AccessRequestResp.self, from: data) {
                if decoded.ok == true {
                    DispatchQueue.main.async {
                        self.requestedOk.insert(domain)
                        self.requestErrorByDomain[domain] = nil
                    }
                    return
                }
                if let e = decoded.error, !e.isEmpty {
                    DispatchQueue.main.async { self.requestErrorByDomain[domain] = e }
                    return
                }
            }

            // fallback: treat as success
            DispatchQueue.main.async {
                self.requestedOk.insert(domain)
                self.requestErrorByDomain[domain] = nil
            }
        }.resume()
    }

    // MARK: - Aggregation

    private func aggregateToMainDomains(_ items: [BlockedDomain]) -> [DomainRow] {
        var map: [String: (count: Int, lastSeen: Date, lastSeenISO: String)] = [:]

        for item in items {
            let main = registrableDomain(from: item.domain)

            let lastSeenDate = isoToDate(item.lastSeenAt) ?? Date.distantPast
            let existing = map[main]

            let newCount = (existing?.count ?? 0) + max(0, item.count)

            // keep max lastSeen
            let (bestDate, bestISO): (Date, String) = {
                if let ex = existing {
                    if lastSeenDate > ex.lastSeen {
                        return (lastSeenDate, item.lastSeenAt)
                    } else {
                        return (ex.lastSeen, ex.lastSeenISO)
                    }
                } else {
                    return (lastSeenDate, item.lastSeenAt)
                }
            }()

            map[main] = (count: newCount, lastSeen: bestDate, lastSeenISO: bestISO)
        }

        return map.map { (key, val) in
            DomainRow(
                id: key,
                domain: key,
                totalCount: val.count,
                lastSeenISO: val.lastSeenISO,
                lastSeenDate: val.lastSeen
            )
        }
    }

    // MARK: - Domain helpers

    private func registrableDomain(from raw: String) -> String {
        let d = normalizeHost(raw)
        guard !d.isEmpty else { return raw }
        if isIPAddress(d) || d == "localhost" { return d }

        let parts = d.split(separator: ".").map(String.init)
        if parts.count <= 2 { return d }

        let twoPartSuffixes: Set<String> = [
            "co.in","com.in","net.in","org.in","gov.in","ac.in",
            "co.uk","org.uk","gov.uk","ac.uk",
            "com.au","net.au","org.au","edu.au","gov.au",
            "co.jp","ne.jp","or.jp",
            "com.br","com.mx"
        ]

        let last2 = parts.suffix(2).joined(separator: ".")
        let last3 = parts.suffix(3).joined(separator: ".")

        if twoPartSuffixes.contains(last2), parts.count >= 3 {
            return last3
        }
        return last2
    }

    private func normalizeHost(_ raw: String) -> String {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if s.hasPrefix("http://") { s = String(s.dropFirst("http://".count)) }
        if s.hasPrefix("https://") { s = String(s.dropFirst("https://".count)) }
        if let cut = s.firstIndex(where: { $0 == "/" || $0 == "?" || $0 == "#" }) {
            s = String(s[..<cut])
        }
        if let colon = s.lastIndex(of: ":"), s.filter({ $0 == ":" }).count == 1 {
            let after = s[s.index(after: colon)...]
            if after.allSatisfy({ $0.isNumber }) {
                s = String(s[..<colon])
            }
        }
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: "."))
        if s.hasPrefix("*.") { s = String(s.dropFirst(2)) }
        return s
    }

    private func isIPAddress(_ s: String) -> Bool {
        let parts = s.split(separator: ".")
        if parts.count == 4 && parts.allSatisfy({ p in
            if let n = Int(p), n >= 0 && n <= 255 { return true }
            return false
        }) { return true }
        if s.contains(":") { return true } // rough IPv6 detection
        return false
    }

    private func isoToDate(_ iso: String) -> Date? {
        guard !iso.isEmpty else { return nil }
        let fmt = ISO8601DateFormatter()
        fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = fmt.date(from: iso) { return d }
        let fmt2 = ISO8601DateFormatter()
        fmt2.formatOptions = [.withInternetDateTime]
        return fmt2.date(from: iso)
    }
}

// MARK: - Enable Banner

private struct EnableProtectionBanner: View {
    let dnsProfileName: String
    let onTap: () -> Void
    let onOpenSettings: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)

                VStack(alignment: .leading, spacing: 2) {
                    Text("Protection isn’t active")
                        .font(.subheadline)
                        .fontWeight(.semibold)

                    Text("Finish enabling SafeNet DNS in Settings.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Spacer()
            }

            Text("Settings → VPN & Network → DNS → select “\(dnsProfileName)”")
                .font(.footnote)
                .foregroundColor(.secondary)

            HStack(spacing: 10) {
                Button {
                    onOpenSettings()
                } label: {
                    HStack {
                        Image(systemName: "gearshape.fill")
                        Text("Open Settings")
                    }
                }
                .buttonStyle(.borderedProminent)

                Button {
                    onTap()
                } label: {
                    HStack {
                        Image(systemName: "checklist")
                        Text("Show Steps")
                    }
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .cornerRadius(14)
    }
}

// MARK: - Enable DNS Sheet

private struct EnableDnsSheet: View {
    let dnsProfileName: String
    let dohURL: String
    let isEnabled: Bool
    let statusText: String
    let onOpenSettings: () -> Void
    let onRecheck: () -> Void

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 12) {
                    Image(systemName: isEnabled ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(isEnabled ? .green : .orange)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(isEnabled ? "Protection is Active" : "Finish Enabling Protection")
                            .font(.headline)

                        Text(isEnabled
                             ? "SafeNet DNS is enabled on this device."
                             : "One quick step in Settings is required.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }

                Text(statusText)
                    .font(.footnote)
                    .foregroundColor(.secondary)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Do this:")
                        .font(.subheadline)
                        .fontWeight(.semibold)

                    Text("1) Open Settings\n2) Go to VPN & Network → DNS\n3) Select “\(dnsProfileName)”")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(Color(.secondarySystemBackground))
                .cornerRadius(12)

                if !dohURL.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("DoH Endpoint")
                            .font(.footnote)
                            .fontWeight(.semibold)

                        Text(dohURL)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .lineLimit(2)

                        Button {
                            UIPasteboard.general.string = dohURL
                        } label: {
                            HStack {
                                Image(systemName: "doc.on.doc")
                                Text("Copy DoH URL")
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                }

                Spacer()

                VStack(spacing: 10) {
                    Button {
                        onOpenSettings()
                    } label: {
                        Text("Open Settings")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        onRecheck()
                    } label: {
                        Text(isEnabled ? "Done" : "I turned it ON — Recheck")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    if !isEnabled {
                        Text("Tip: After enabling, come back to SafeNet — we’ll verify automatically.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.top, 2)
                    }
                }
            }
            .padding()
            .navigationTitle("Enable SafeNet DNS")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Pairing response model (unchanged)

@preconcurrency
struct PairingResponse: Codable {
    let ok: Bool
    let token: String
    let device: Device
    let user: User
    let pairing: PairingMeta
    let role: String
    let userId: String
    let agh: String?
    let dns: DNSConfig?
    let childId: String?
    let parentId: String?

    struct Device: Codable {
        let id: Int
        let userId: String
        let uniqueId: String
        let uniqueTag: String?
        let deviceName: String?
        let platform: String?
        let aghIds: [String]?
        let aghClientName: String?
    }

    struct User: Codable {
        let name: String?
        let email: String?
        let phone: String?
        let uniqueTag: String?
        let role: String
        let cid: String?
    }

    struct PairingMeta: Codable {
        let code: String
        let consumedAt: String
    }

    struct DNSConfig: Codable {
        let doh: String
        let dot: String
        let clientId: String?
        let dohWithId: String?
    }

    var cidEffective: String { user.cid ?? dns?.clientId ?? "" }
    var deviceIdEffective: String { String(device.id) }
    var childNameEffective: String { user.name ?? "Child" }

    // ✅ FIX: prefer USER uniqueTag first (user_xxx), fallback to device uniqueTag
    var userTagEffective: String { user.uniqueTag ?? device.uniqueTag ?? "" }
}
