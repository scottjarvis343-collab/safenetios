import NetworkExtension
import Network

/// NOTE:
/// This PacketTunnelProvider is no longer used by the main app UI.
/// We are switching to the modern DNS Settings approach (NEDNSSettingsManager + DoH),
/// which does NOT require a full packet tunnel.
///
/// Keeping this file so the existing extension target does not break if it still exists.
final class PacketTunnelProvider: NEPacketTunnelProvider {

    private let logPrefix = "[SafeNet-iOS]"
    private var isTunnelRunning = false

    override func startTunnel(
        options: [String : NSObject]?,
        completionHandler: @escaping (Error?) -> Void
    ) {
        print("\(logPrefix) startTunnel() – DEPRECATED (DNS Settings approach is used now)")
        isTunnelRunning = true
        completionHandler(nil)
    }

    override func stopTunnel(
        with reason: NEProviderStopReason,
        completionHandler: @escaping () -> Void
    ) {
        print("\(logPrefix) stopTunnel() – DEPRECATED")
        isTunnelRunning = false
        completionHandler()
    }
}
