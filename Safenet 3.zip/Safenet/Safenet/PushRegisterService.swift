import Foundation

final class PushRegisterService {
    static let shared = PushRegisterService()
    private init() {}

    private let registerURL = URL(string: "https://api.safenettechnology.com/public/push/register")!
    private let unregisterURL = URL(string: "https://api.safenettechnology.com/public/push/unregister")!

    /// Registers APNS token with backend.
    /// IMPORTANT: sends deviceId when available so server can do per-device silent pings.
    func register(tokenHex: String, userTag: String, deviceId: Int?, completion: @escaping (Bool) -> Void) {
        var req = URLRequest(url: registerURL)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        var body: [String: Any] = [
            "user_tag": userTag,   // snake_case matches backend
            "token": tokenHex
        ]
        if let deviceId = deviceId {
            body["deviceId"] = deviceId
        }

        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("SafeNet[PushRegister] register failed:", err.localizedDescription)
                completion(false)
                return
            }

            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""

            print("SafeNet[PushRegister] status:", code, "body:", text)

            completion((200...299).contains(code))
        }.resume()
    }

    /// Optional: call on logout / unpair if you want.
    func unregister(tokenHex: String, completion: @escaping (Bool) -> Void) {
        var req = URLRequest(url: unregisterURL)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = ["token": tokenHex]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("SafeNet[PushRegister] unregister failed:", err.localizedDescription)
                completion(false)
                return
            }

            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let text = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""

            print("SafeNet[PushRegister] unregister status:", code, "body:", text)

            completion((200...299).contains(code))
        }.resume()
    }
}
