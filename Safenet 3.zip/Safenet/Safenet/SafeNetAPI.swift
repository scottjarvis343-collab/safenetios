import Foundation

enum SafeNetAPI {

    static func uploadPushToken(_ token: String) {
        guard
            let deviceId = SharedDefaults.instance.string(forKey: SafeNetConfig.sharedDeviceIdKey)
        else { return }

        var req = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("devices/push-token"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "deviceId": deviceId,
            "token": token,
            "platform": "ios"
        ]

        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: req).resume()
    }
}
