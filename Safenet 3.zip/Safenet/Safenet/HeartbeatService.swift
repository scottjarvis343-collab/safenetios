import Foundation
import NetworkExtension

final class HeartbeatService {
    static let shared = HeartbeatService()
    private init() {}

    private let ud = SharedDefaults.instance
    private let kLastLocalHeartbeatAt = "safenet_last_local_heartbeat_at"

    /// Fire a heartbeat immediately.
    /// - Parameters:
    ///   - reason: "launch" | "foreground" | "bg_refresh" | "silent_push" etc
    ///   - type: optional event type (ex: "ios_ping_ack")
    func sendNow(reason: String, type: String? = nil, completion: ((Bool) -> Void)? = nil) {

        let cid = (ud.string(forKey: SafeNetConfig.sharedCIDKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let deviceUniqueTag = (ud.string(forKey: SafeNetConfig.sharedDeviceUniqueTagKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let dohUrl = (ud.string(forKey: SafeNetConfig.sharedDoHURLKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cid.isEmpty, !deviceUniqueTag.isEmpty else {
            completion?(false)
            return
        }

        let mgr = NEDNSSettingsManager.shared()
        mgr.loadFromPreferences { (error: Error?) in
            // Even if load fails, we can still send heartbeat with best-effort values
            let dnsEnabled = mgr.isEnabled
            let hasSavedDnsConfig = (mgr.dnsSettings != nil)

            var payload: [String: Any] = [
                "deviceId": deviceUniqueTag,   // Device.uniqueTag
                "cid": cid,
                "platform": "ios",
                "dnsEnabled": dnsEnabled,
                "hasSavedDnsConfig": hasSavedDnsConfig,
                "ts": Int(Date().timeIntervalSince1970),
                "reason": reason
            ]

            if let type = type, !type.isEmpty {
                payload["type"] = type
            }

            if !dohUrl.isEmpty {
                payload["dohUrl"] = dohUrl
            }

            if let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String { payload["appVersion"] = v }
            if let b = Bundle.main.infoDictionary?["CFBundleVersion"] as? String { payload["build"] = b }

            self.postHeartbeat(payload: payload) { ok in
                if ok {
                    self.ud.set(Date().timeIntervalSince1970, forKey: self.kLastLocalHeartbeatAt)
                    self.ud.synchronize()
                }
                completion?(ok)
            }
        }
    }

    private func postHeartbeat(payload: [String: Any], completion: @escaping (Bool) -> Void) {
        var req = URLRequest(url: SafeNetConfig.apiBaseURL.appendingPathComponent("devices/heartbeat"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 12

        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            completion(false)
            return
        }

        URLSession.shared.dataTask(with: req) { _, resp, err in
            if err != nil { completion(false); return }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            completion((200...299).contains(code))
        }.resume()
    }
}
