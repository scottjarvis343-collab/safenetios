import UIKit
import UserNotifications
import BackgroundTasks
import Foundation

final class AppDelegate: NSObject, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil
    ) -> Bool {

        // Silent APNs token registration + upload
        PushTokenManager.shared.configure()
        PushTokenManager.shared.registerForSilentPush()
        PushTokenManager.shared.tryUploadNow(reason: "launch_tryUploadNow")

        // BG heartbeat
        registerBackgroundTasks()
        scheduleHeartbeatRefresh()

        HeartbeatService.shared.sendNow(reason: "launch")

        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        scheduleHeartbeatRefresh()
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        HeartbeatService.shared.sendNow(reason: "foreground")
        scheduleHeartbeatRefresh()

        // If pairing/userTag/deviceId got set while app was inactive
        PushTokenManager.shared.tryUploadNow(reason: "didBecomeActive")
    }

    // ✅ Silent push wakeup (aps.content-available=1)
    func application(
        _ application: UIApplication,
        didReceiveRemoteNotification userInfo: [AnyHashable : Any],
        fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void
    ) {
        print("SafeNet[APNS] silent push received:", userInfo.keys.map { "\($0)" }.joined(separator: ","))

        // IMPORTANT: send heartbeat as "silent_push" so server can treat as ping ack
        HeartbeatService.shared.sendNow(reason: "silent_push") { ok in
            completionHandler(ok ? .newData : .failed)
        }
    }

    // MARK: APNS callbacks

    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        PushTokenManager.shared.didRegisterForRemoteNotifications(deviceToken: deviceToken)
    }

    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        PushTokenManager.shared.didFailToRegister(error: error)
    }

    // MARK: BG Task

    private func registerBackgroundTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: SafeNetConfig.bgHeartbeatTaskId, using: nil) { task in
            self.handleHeartbeatRefresh(task: task as! BGAppRefreshTask)
        }
    }

    private func scheduleHeartbeatRefresh() {
        let req = BGAppRefreshTaskRequest(identifier: SafeNetConfig.bgHeartbeatTaskId)
        req.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
        do { try BGTaskScheduler.shared.submit(req) } catch { }
    }

    private func handleHeartbeatRefresh(task: BGAppRefreshTask) {
        scheduleHeartbeatRefresh()

        task.expirationHandler = {
            task.setTaskCompleted(success: false)
        }

        HeartbeatService.shared.sendNow(reason: "bg_refresh") { ok in
            task.setTaskCompleted(success: ok)
        }
    }
}
