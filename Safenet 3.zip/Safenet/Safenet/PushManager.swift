import Foundation
import UIKit
import UserNotifications

final class PushTokenManager: NSObject, UNUserNotificationCenterDelegate {

    static let shared = PushTokenManager()
    private let ud = SharedDefaults.instance

    private let kApnsTokenHex = "safenet_apns_token_hex"
    private let kLastUploadedUserTag = "safenet_apns_last_uploaded_usertag"
    private let kLastUploadedTokenHex = "safenet_apns_last_uploaded_token_hex"
    private let kLastUploadedDeviceId = "safenet_apns_last_uploaded_deviceid"

    private override init() { super.init() }

    func configure() {
        // If later you add visible notifications, keep this.
        UNUserNotificationCenter.current().delegate = self
    }

    /// ✅ Silent-only registration (no authorization prompt)
    func registerForSilentPush() {
        DispatchQueue.main.async {
            UIApplication.shared.registerForRemoteNotifications()
        }
    }

    func didRegisterForRemoteNotifications(deviceToken: Data) {
        let tokenHex = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()

        ud.set(tokenHex, forKey: kApnsTokenHex)
        ud.synchronize()

        print("SafeNet[APNS] token received:", String(tokenHex.prefix(12)), "…")

        tryUploadNow(reason: "didRegisterForRemoteNotifications")
    }

    func didFailToRegister(error: Error) {
        print("SafeNet[APNS] registration failed:", error.localizedDescription)
    }

    /// Call this whenever pairing completes / userTag saved / deviceId saved
    func notifyIdentityChanged() {
        tryUploadNow(reason: "identityChanged")
    }

    func tryUploadNow(reason: String) {
        let tokenHex = (ud.string(forKey: kApnsTokenHex) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let userTag = (ud.string(forKey: SafeNetConfig.sharedUserTagKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        // deviceId optional but recommended so server can ping a specific device
        let deviceIdRaw = ud.object(forKey: SafeNetConfig.sharedDeviceIdKey)
        let deviceId: Int? = {
            if let n = deviceIdRaw as? Int { return n }
            if let s = deviceIdRaw as? String, let n = Int(s) { return n }
            return nil
        }()

        if tokenHex.isEmpty || userTag.isEmpty {
            // Missing pairing or token
            return
        }

        // De-dupe uploads
        let lastTag = ud.string(forKey: kLastUploadedUserTag) ?? ""
        let lastTok = ud.string(forKey: kLastUploadedTokenHex) ?? ""
        let lastDidStr = ud.string(forKey: kLastUploadedDeviceId) ?? ""
        let didStr = deviceId != nil ? String(deviceId!) : ""

        if lastTag == userTag && lastTok == tokenHex && lastDidStr == didStr {
            return
        }

        print("SafeNet[APNS] uploading token (\(reason)) userTag=\(userTag) deviceId=\(didStr.isEmpty ? "nil" : didStr)")

        PushRegisterService.shared.register(tokenHex: tokenHex, userTag: userTag, deviceId: deviceId) { ok in
            if ok {
                self.ud.set(userTag, forKey: self.kLastUploadedUserTag)
                self.ud.set(tokenHex, forKey: self.kLastUploadedTokenHex)
                self.ud.set(didStr, forKey: self.kLastUploadedDeviceId)
                self.ud.synchronize()
                print("SafeNet[APNS] upload OK")
            } else {
                print("SafeNet[APNS] upload FAILED")
            }
        }
    }

    // Foreground presentation (only matters if you later send visible alerts)
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }
}
